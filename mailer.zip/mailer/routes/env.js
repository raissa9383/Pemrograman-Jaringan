module.exports = {
    EMAIL : 'putiraissa@infitech.or.id',
    PASSWORD : 'vvvw yktl wdvx xbqc'
}