//NODE.JS MODULE SYSTEM
//Import Core Module System
const fs = require('fs')

fs.writeFileSync('catatan.txt', 'Nama saya Puti Raissa Razani')
fs.appendFileSync('catatan.txt', 'Saya tinggal di Padang')
/*
//Import file pada node.js
const catatan = require('./catatan.js')
const pesann = catatan()
console.log(pesann)
*/

/*
//Import npm
const validator = require('validator')
const ambilCatatan = require('./catatan.js')
const pesan = ambilCatatan()
console.log(pesan)
console.log(validator.isURL('https://raissa.com'))
*/

//chalk
const chalk = require('chalk');
console.log(chalk.blue('Hello world!'));
console.log(chalk.blue.bgRed.bold('Hello world!'));
console.log(chalk.green(
	'I am a green line ' +
	chalk.blue.underline.bold('with a blue substring') +
	' that becomes green again!'
));

console.log(chalk.keyword('orange')('Yay for orange colored text!'));
console.log(chalk.rgb(123, 45, 67).underline('Underlined reddish color'));
console.log(chalk.hex('#DEADED').bold('Bold gray!'));

const error = chalk.bold.red;
const warning = chalk.keyword('orange');

console.log(error('Error!'));
console.log(warning('Warning!'));


//COMMAND LINE ARGUMENTS
//Mendapatkan input dari pengguna
const command = process.argv[2]
console.log(process.argv[2])

//if (command === 'tambah'){
  //  console.log('Tambah Catatan')
//} else if (command === 'hapus') {
//    console.log('Hapus Catatan')
//}

//Argument Parsing
const catatan = require('./catatan.js')
const yargs = require('yargs')
yargs.command({
    command: 'tambah',
    describe: 'tambah sebuah catatan baru',
    builder: {
        judul: {
            describe: 'Judul catatan',
            demandOption: true,
            type: 'string'
        },
        isi: {
            describe: 'Isi catatan',
            demandOption: true,
            type: 'string'
        }
    },
    handler: function (argv) {
        catatan.tambahCatatan(argv.judul, argv.isi)
    }
})

yargs.command({
    command: 'hapus',
    describe: 'hapus catatan',
    builder:{
        judul: {
            describe: 'Judul catatan',
            demandOption: true,
            type: 'string'
        }
    },
    handler: function (argv) {
        catatan.hapusCatatan(argv.judul)
    }
})

yargs.command({
    command: 'list',
    describe: 'list catatan',
    handler: function () {
        console.log('List Catatan')
    }
})

yargs.command({
    command: 'read',
    describe: 'membaca catatan',
    handler: function () {
        console.log('Catatan Telah Dibaca')
    }
})
yargs.parse()

