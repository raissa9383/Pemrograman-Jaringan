//menyimpan data json
const fs = require('fs')


const buku = {
    judul: 'Pemrograman Jaringan',
    penulis: 'Puti Raissa Razani'
}

const bookJSON = JSON.stringify(buku)
fs.writeFileSync('1-jsontest.json', bookJSON) 


//menbaca data json
const dataBuffer = fs.readFileSync('1-jsontest.json')
const dataJSON = dataBuffer.toString()
const data = JSON.parse(dataJSON)
console.log(data)
