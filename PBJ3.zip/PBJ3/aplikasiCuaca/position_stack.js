const request = require('request');
const geocodeURL = 'https://api.positionstack.com/v1/forward?access_key=56366671fee255dcb794f5b63c27df00&query=Padang&limit=2'

request({ url: geocodeURL, json: true }, (error, response) => {
        const latitude = response.body.features[0].center[1]
        const longitude = response.body.features[0].center[0];
        console.log(latitude, longitude);
    }
)