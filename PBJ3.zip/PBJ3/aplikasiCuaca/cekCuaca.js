const request = require('postman-request') 
const urlCuaca = 
'http://api.weatherstack.com/current?access_key=5f85d6db9ca0312f38558a818f1a91d3&query=-0.897100976497388,100.35072745874929&units=f'

request({ url : urlCuaca, json: true}, (error, response) => {
    console.log('Saat ini suhu di luar mencapai ' + response.body.current.temperature + ' derajat celcius. Kemungkinan terjadinya hujan adalah ' + response.body.current.precip + '%')
    console.log('Saat ini cuaca dapat dideskripsikan dengan ' + response.body.current.weather_descriptions[0] )
})
