const request = require('postman-request') 
const url = 
'http://api.weatherstack.com/current?access_key=5f85d6db9ca0312f38558a818f1a91d3&query=-0.897100976497388,100.35072745874929' 
request({ url: url }, (error, response) => { 
//console.log(response) 
const data = JSON.parse(response.body) 
//console.log(data) 
//console.log(data.current) 
console.log(data.current.temperature) 
})